html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EIN — Environmental Intelligence Network</title>
<style>
  :root {
    --bg-dark: #0b1120;
    --bg-panel: #111827;
    --bg-card: #1f2937;
    --text-main: #e5e7eb;
    --text-muted: #9ca3af;
    --color-green: #10b981;
    --color-yellow: #fbbf24;
    --color-orange: #f97316;
    --color-red: #ef4444;
    --color-gray: #6b7280;
    --color-blue: #3b82f6;
    --color-fire: #ea580c;
    --border-color: #374151;
    --font-mono: 'Consolas', 'Courier New', monospace;
    --font-sans: 'Segoe UI', system-ui, sans-serif;
  }
  
  * { box-sizing: border-box; }
  
  body {
    margin: 0;
    padding: 0;
    background-color: var(--bg-dark);
    color: var(--text-main);
    font-family: var(--font-sans);
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .mono { font-family: var(--font-mono); }

  /* Header */
  header {
    background-color: var(--bg-panel);
    border-bottom: 1px solid var(--border-color);
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .header-title {
    font-size: 1.2rem;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 15px;
  }
  .demo-badge {
    background-color: var(--color-orange);
    color: #fff;
    font-size: 0.7rem;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: bold;
    letter-spacing: 1px;
  }
  
  .top-stats {
    display: flex;
    gap: 20px;
    font-family: var(--font-mono);
    font-size: 0.85rem;
  }
  .stat-item {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }
  .stat-label { color: var(--text-muted); font-size: 0.7rem; text-transform: uppercase; }
  .stat-val { font-size: 1.1rem; }

  /* Tabs Navigation */
  .tabs {
    display: flex;
    background-color: var(--bg-panel);
    border-bottom: 1px solid var(--border-color);
  }
  .tab-btn {
    background: none;
    border: none;
    color: var(--text-muted);
    padding: 12px 24px;
    cursor: pointer;
    font-size: 0.95rem;
    border-bottom: 3px solid transparent;
    transition: all 0.2s;
  }
  .tab-btn:hover { color: var(--text-main); }
  .tab-btn.active {
    color: var(--color-blue);
    border-bottom-color: var(--color-blue);
  }

  /* Main Content Area */
  .main-content {
    flex: 1;
    position: relative;
    overflow: hidden;
  }
  
  .tab-pane {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    display: none;
    padding: 20px;
    overflow-y: auto;
  }
  .tab-pane.active { display: flex; gap: 20px; }

  /* Common UI Elements */
  .panel {
    background-color: var(--bg-panel);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 15px;
    display: flex;
    flex-direction: column;
  }
  .panel-title {
    font-size: 0.9rem;
    color: var(--text-muted);
    text-transform: uppercase;
    margin-bottom: 15px;
    letter-spacing: 1px;
  }
  
  /* TAB 1: Live Risk Map */
  #tab-map { flex-direction: row; }
  .map-container {
    flex: 2;
    position: relative;
    background-color: #0f172a;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    overflow: hidden;
    background-image: 
      linear-gradient(rgba(55, 65, 81, 0.3) 1px, transparent 1px),
      linear-gradient(90deg, rgba(55, 65, 81, 0.3) 1px, transparent 1px);
    background-size: 40px 40px;
  }
  
  .node-dot {
    position: absolute;
    width: 16px; height: 16px;
    border-radius: 50%;
    transform: translate(-50%, -50%);
    cursor: pointer;
    box-shadow: 0 0 10px currentColor;
    transition: transform 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .node-dot:hover { transform: translate(-50%, -50%) scale(1.3); }
  .node-dot::after {
    content: '';
    position: absolute;
    width: 100%; height: 100%;
    border-radius: 50%;
    border: 2px solid currentColor;
    animation: pulse 2s infinite;
  }
  .node-dot.status-normal { color: var(--color-green); background: var(--color-green); }
  .node-dot.status-watch { color: var(--color-yellow); background: var(--color-yellow); }
  .node-dot.status-warning { color: var(--color-orange); background: var(--color-orange); }
  .node-dot.status-critical { color: var(--color-red); background: var(--color-red); }
  .node-dot.status-offline { color: var(--color-gray); background: var(--color-gray); box-shadow: none; }
  .node-dot.status-offline::after { display: none; }

  @keyframes pulse {
    0% { transform: scale(1); opacity: 0.8; }
    100% { transform: scale(2.5); opacity: 0; }
  }
  
  .side-panel {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }
  
  .alerts-list {
    flex: 1;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .alert-item {
    background-color: var(--bg-card);
    padding: 10px;
    border-left: 4px solid var(--color-red);
    border-radius: 4px;
    font-size: 0.85rem;
  }
  .alert-item.warning { border-left-color: var(--color-orange); }
  .alert-item.watch { border-left-color: var(--color-yellow); }
  
  .node-detail-card {
    background-color: var(--bg-card);
    padding: 15px;
    border-radius: 8px;
    display: none; /* hidden initially */
    flex-direction: column;
    gap: 10px;
    border: 1px solid var(--border-color);
  }
  .detail-header { display: flex; justify-content: space-between; align-items: center; }
  .badge { padding: 3px 6px; border-radius: 4px; font-size: 0.7rem; font-weight: bold; }
  .badge.normal { background: rgba(16, 185, 129, 0.2); color: var(--color-green); }
  .badge.failed { background: rgba(239, 68, 68, 0.2); color: var(--color-red); }
  .badge.suspicious { background: rgba(249, 115, 22, 0.2); color: var(--color-orange); }
  
  .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 0.85rem; }
  .detail-lbl { color: var(--text-muted); }
  
  canvas.sparkline { width: 100%; height: 60px; background: #0f172a; border-radius: 4px; margin-top: 10px; }

  /* TAB 2: Digital Twin Simulator */
  #tab-sim { flex-direction: column; gap: 20px; }
  .sim-controls {
    display: flex;
    gap: 15px;
    background-color: var(--bg-panel);
    padding: 15px;
    border-radius: 8px;
    border: 1px solid var(--border-color);
    align-items: center;
    flex-wrap: wrap;
  }
  button {
    background-color: var(--bg-card);
    color: var(--text-main);
    border: 1px solid var(--border-color);
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-family: var(--font-sans);
    transition: background-color 0.2s;
  }
  button:hover { background-color: #374151; }
  button.action-btn { border-color: var(--color-blue); }
  button.action-btn:hover { background-color: rgba(59, 130, 246, 0.2); }
  select {
    background-color: var(--bg-card);
    color: var(--text-main);
    border: 1px solid var(--border-color);
    padding: 8px;
    border-radius: 4px;
    font-family: var(--font-sans);
  }

  .readouts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
  }
  .readout-card {
    background-color: var(--bg-card);
    padding: 20px;
    border-radius: 8px;
    border: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .readout-val {
    font-size: 2.5rem;
    font-family: var(--font-mono);
    margin: 10px 0;
    transition: color 0.5s ease;
  }
  
  .flashing-banner {
    display: none;
    background-color: rgba(239, 68, 68, 0.2);
    border: 1px solid var(--color-red);
    color: var(--color-red);
    padding: 15px;
    border-radius: 8px;
    text-align: center;
    font-weight: bold;
    font-size: 1.2rem;
    animation: flash 1s infinite;
    margin-bottom: 10px;
  }
  @keyframes flash {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  .ai-reasoning {
    background-color: #0f172a;
    border-left: 4px solid var(--color-blue);
    padding: 15px;
    font-family: var(--font-mono);
    font-size: 0.9rem;
    color: #cbd5e1;
    min-height: 80px;
  }

  /* SVG Link Graph in Simulator */
  #sim-link-graph {
    width: 100%;
    height: 120px;
    background: #0f172a;
    border-radius: 8px;
    margin-top: 15px;
    display: none;
  }

  /* TAB 3: RF Mesh Network */
  #tab-mesh { flex-direction: row; }
  .mesh-container {
    flex: 2;
    background-color: #0f172a;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  #mesh-svg { width: 100%; height: 100%; }
  
  .mesh-log {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 15px;
  }
  .log-console {
    flex: 1;
    background-color: #000;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 10px;
    font-family: var(--font-mono);
    font-size: 0.8rem;
    color: var(--color-green);
    overflow-y: auto;
    display: flex;
    flex-direction: column;
  }
  .log-entry { margin-bottom: 4px; }
  .log-entry.missed { color: var(--color-yellow); }
  .log-entry.offline { color: var(--color-red); }
  
  .mesh-controls {
    background-color: var(--bg-panel);
    padding: 15px;
    border-radius: 8px;
    border: 1px solid var(--border-color);
  }

  /* Number animation transitions */
  .val-transition {
    /* transition is managed via JS for smooth counter effect */
  }

  /* Dynamic Styles */
  .text-normal { color: var(--color-green); }
  .text-watch { color: var(--color-yellow); }
  .text-warning { color: var(--color-orange); }
  .text-critical { color: var(--color-red); }
  
  /* Link Lines */
  .mesh-link { stroke: var(--color-green); stroke-width: 2; transition: stroke 1s, opacity 1s, stroke-dasharray 1s; }
  .mesh-link.degraded { stroke: var(--color-orange); stroke-dasharray: 5, 5; }
  .mesh-link.broken { stroke: var(--color-red); opacity: 0.3; stroke-dasharray: 2, 8; }
  
  .mesh-node { fill: var(--color-blue); transition: fill 1s; }
  .mesh-node.fire { fill: var(--color-fire); }
  .mesh-node.offline { fill: var(--color-gray); }
  .mesh-label { fill: var(--text-main); font-size: 12px; font-family: var(--font-mono); user-select: none;}
  .link-label { fill: var(--text-muted); font-size: 10px; font-family: var(--font-mono); user-select: none; }

</style>
</head>
<body>

  <!-- Header -->
  <header>
    <div class="header-title">
      EIN <span style="font-weight:normal;color:var(--text-muted)">— Live Monitoring</span>
      <span class="demo-badge">DEMO DATA</span>
    </div>
    <div class="top-stats">
      <div class="stat-item"><span class="stat-label">Total Nodes</span><span class="stat-val" id="stat-total">0</span></div>
      <div class="stat-item"><span class="stat-label">Active Alerts</span><span class="stat-val text-warning" id="stat-alerts">0</span></div>
      <div class="stat-item"><span class="stat-label">Offline</span><span class="stat-val text-critical" id="stat-offline">0</span></div>
      <div class="stat-item"><span class="stat-label">Avg Battery</span><span class="stat-val" id="stat-battery">0%</span></div>
    </div>
  </header>

  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn active" onclick="switchTab('tab-map', this)">LIVE RISK MAP</button>
    <button class="tab-btn" onclick="switchTab('tab-sim', this)">DIGITAL TWIN SIMULATOR</button>
    <button class="tab-btn" onclick="switchTab('tab-mesh', this)">RF MESH NETWORK</button>
  </div>

  <!-- Main Content -->
  <div class="main-content">
  
    <!-- TAB 1: Live Risk Map -->
    <div id="tab-map" class="tab-pane active">
      <div class="map-container" id="map-container">
        <!-- Nodes injected via JS -->
      </div>
      
      <div class="side-panel">
        <div class="panel" style="flex:1">
          <div class="panel-title">Active Alerts</div>
          <div class="alerts-list" id="alerts-list">
            <!-- Alerts injected via JS -->
          </div>
        </div>
        
        <div class="node-detail-card" id="node-detail-card">
          <div class="detail-header">
            <strong id="detail-id" class="mono" style="font-size:1.2rem">NODE --</strong>
            <span id="detail-type" style="color:var(--text-muted)">--</span>
          </div>
          <div class="detail-grid">
            <div><div class="detail-lbl">Status</div><div id="detail-status" style="font-weight:bold">--</div></div>
            <div><div class="detail-lbl">Health</div><div><span id="detail-health" class="badge normal">Normal</span></div></div>
            <div><div class="detail-lbl">Battery</div><div id="detail-batt" class="mono">--%</div></div>
            <div><div class="detail-lbl">AI Confidence</div><div id="detail-conf" class="mono">--%</div></div>
          </div>
          <div style="margin-top:5px">
            <div class="detail-lbl">Current Readings</div>
            <div id="detail-readings" class="mono" style="font-size:0.9rem">--</div>
          </div>
          <canvas class="sparkline" id="detail-sparkline"></canvas>
        </div>
      </div>
    </div>

    <!-- TAB 2: Digital Twin Simulator -->
    <div id="tab-sim" class="tab-pane">
      <div class="flashing-banner" id="sim-banner">
        🔴 CRITICAL ALERT — Downstream warning issued
      </div>
    
      <div class="sim-controls">
        <select id="sim-node-select">
          <option value="F-102">Flood Node F-102</option>
          <option value="A-405">Air Quality A-405</option>
        </select>
        <div style="width:1px;height:20px;background:var(--border-color);margin:0 10px;"></div>
        <button class="action-btn" onclick="runSim('rain')">Simulate Heavy Rain</button>
        <button class="action-btn" onclick="runSim('failure')">Simulate Sensor Failure</button>
        <button class="action-btn" onclick="runSim('fire')">Simulate Fire Risk (RF Anomaly)</button>
        <button onclick="runSim('reset')">Reset to Normal</button>
      </div>

      <div class="readouts-grid" id="sim-readouts">
        <!-- Readout cards injected via JS based on scenario -->
      </div>
      
      <svg id="sim-link-graph">
        <!-- SVG injected for fire scenario -->
      </svg>

      <div class="panel" style="margin-top:auto;">
        <div class="panel-title">AI Reasoning Matrix</div>
        <div class="ai-reasoning" id="sim-reasoning">
          System nominal. Baseline readings within expected seasonal parameters. No immediate hazards detected.
        </div>
      </div>
    </div>

    <!-- TAB 3: RF Mesh Network -->
    <div id="tab-mesh" class="tab-pane">
      <div class="mesh-container">
        <svg id="mesh-svg"></svg>
        <div id="mesh-summary" style="position:absolute; bottom:20px; right:20px; background:rgba(0,0,0,0.8); padding:15px; border:1px solid var(--color-orange); border-radius:8px; display:none; max-width:300px;">
          <strong style="color:var(--color-orange)">🔥 ALERT ISOLATED</strong><br>
          <span style="font-size:0.85rem;font-family:var(--font-mono);color:#e5e7eb" id="mesh-summary-text"></span>
        </div>
      </div>
      
      <div class="mesh-log">
        <div class="mesh-controls">
          <div class="panel-title">Mesh Diagnostics</div>
          <button class="action-btn" style="width:100%" onclick="triggerMeshFire()">Trigger Fire Event at Node N-08</button>
        </div>
        <div class="log-console" id="mesh-console">
          <!-- Logs injected via JS -->
        </div>
      </div>
    </div>

  </div>

<script>
/* =========================================================
   CORE LOGIC & UTILS
========================================================= */

// Smooth number transition utility
const activeTweens = {};
function tweenNumber(element, start, end, duration, formatFn, key) {
  if (activeTweens[key]) cancelAnimationFrame(activeTweens[key]);
  
  const startTime = performance.now();
  const update = (currentTime) => {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // easeInOutQuad
    const ease = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
    
    const currentVal = start + (end - start) * ease;
    element.innerHTML = formatFn(currentVal);
    
    if (progress < 1) {
      activeTweens[key] = requestAnimationFrame(update);
    }
  };
  activeTweens[key] = requestAnimationFrame(update);
}

function switchTab(tabId, btn) {
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  btn.classList.add('active');
  
  if(tabId === 'tab-mesh' && !meshInitialized) initMesh();
}

function pad(n) { return n < 10 ? '0'+n : n; }
function getTime() {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

/* =========================================================
   TAB 1: LIVE RISK MAP
========================================================= */
const mapNodes = [];
const hazards = [
  { type: 'Flood', icon: '💧', color: 'var(--color-blue)', prefix: 'F-' },
  { type: 'Fire', icon: '🔥', color: 'var(--color-fire)', prefix: 'R-' },
  { type: 'Air Quality', icon: '🌫️', color: 'var(--color-gray)', prefix: 'A-' }
];

function initMap() {
  const container = document.getElementById('map-container');
  const w = container.clientWidth || 800;
  const h = container.clientHeight || 600;
  
  let activeAlertsCount = 0;
  let offlineCount = 0;
  let totalBatt = 0;
  
  for(let i=0; i<20; i++) {
    const haz = hazards[i % 3];
    const id = haz.prefix + (100 + i);
    const x = 10 + Math.random() * 80; // %
    const y = 10 + Math.random() * 80; // %
    
    // Determine status
    const rand = Math.random();
    let status = 'normal';
    let riskProb = Math.floor(Math.random()*20);
    
    if(rand > 0.9) { status = 'critical'; riskProb = 90 + Math.random()*9; activeAlertsCount++; }
    else if(rand > 0.8) { status = 'warning'; riskProb = 60 + Math.random()*29; activeAlertsCount++; }
    else if(rand > 0.7) { status = 'watch'; riskProb = 30 + Math.random()*29; }
    else if(rand > 0.95) { status = 'offline'; offlineCount++; }
    
    const batt = status === 'offline' ? 0 : 40 + Math.floor(Math.random()*60);
    totalBatt += batt;
    
    const node = { id, type: haz.type, icon: haz.icon, x, y, status, batt, prob: riskProb.toFixed(1) };
    mapNodes.push(node);
    
    // Create DOM element
    const el = document.createElement('div');
    el.className = `node-dot status-${status}`;
    el.style.left = `${x}%`;
    el.style.top = `${y}%`;
    el.innerHTML = haz.icon;
    el.onclick = () => showNodeDetail(node);
    container.appendChild(el);
    
    // Add to alerts list if warning/critical
    if(status === 'warning' || status === 'critical') {
      const alertList = document.getElementById('alerts-list');
      const item = document.createElement('div');
      item.className = `alert-item ${status}`;
      item.innerHTML = `
        <div class="mono" style="margin-bottom:4px;color:var(--text-muted)">${getTime()}</div>
        ${status==='critical'?'🔴':'🟠'} ${haz.type} risk &mdash; Node ${id} &mdash; ${node.prob}% conf
      `;
      alertList.appendChild(item);
    }
  }
  
  // Update Header Stats
  document.getElementById('stat-total').innerText = 20;
  document.getElementById('stat-alerts').innerText = activeAlertsCount;
  document.getElementById('stat-offline').innerText = offlineCount;
  document.getElementById('stat-battery').innerText = Math.floor(totalBatt / 20) + '%';
  
  // Select first node by default
  if(mapNodes.length>0) showNodeDetail(mapNodes[0]);
}

function showNodeDetail(node) {
  const card = document.getElementById('node-detail-card');
  card.style.display = 'flex';
  
  document.getElementById('detail-id').innerText = node.id;
  document.getElementById('detail-type').innerText = node.type;
  
  const statusEl = document.getElementById('detail-status');
  statusEl.innerText = node.status.toUpperCase();
  statusEl.className = `text-${node.status}`;
  
  const healthEl = document.getElementById('detail-health');
  if(node.status === 'offline') {
    healthEl.innerText = 'Failed';
    healthEl.className = 'badge failed';
  } else {
    healthEl.innerText = 'Normal';
    healthEl.className = 'badge normal';
  }
  
  document.getElementById('detail-batt').innerText = node.batt + '%';
  document.getElementById('detail-conf').innerText = node.status === 'offline' ? 'N/A' : node.prob + '%';
  
  // Mock readings
  let readings = '';
  if(node.type === 'Flood') readings = `Water: ${(Math.random()*4).toFixed(2)}m | Flow: ${(Math.random()*10).toFixed(1)}m/s`;
  if(node.type === 'Fire') readings = `Temp: ${(20+Math.random()*30).toFixed(1)}°C | Hum: ${(30+Math.random()*40).toFixed(0)}%`;
  if(node.type === 'Air Quality') readings = `PM2.5: ${(10+Math.random()*150).toFixed(0)}µg/m³ | CO2: ${(400+Math.random()*500).toFixed(0)}ppm`;
  if(node.status === 'offline') readings = 'No data';
  
  document.getElementById('detail-readings').innerText = readings;
  
  drawSparkline(node);
}

function drawSparkline(node) {
  const cvs = document.getElementById('detail-sparkline');
  const ctx = cvs.getContext('2d');
  const w = cvs.width = cvs.clientWidth;
  const h = cvs.height = cvs.clientHeight;
  
  ctx.clearRect(0,0,w,h);
  if(node.status === 'offline') return;
  
  ctx.beginPath();
  ctx.strokeStyle = node.status === 'critical' ? '#ef4444' : 
                    node.status === 'warning' ? '#f97316' : 
                    node.status === 'watch' ? '#fbbf24' : '#10b981';
  ctx.lineWidth = 2;
  
  const pts = 20;
  const step = w / (pts-1);
  let prevY = h/2;
  
  // Create a trend based on status
  const trend = (node.status === 'critical' || node.status === 'warning') ? -2 : 0;
  
  for(let i=0; i<pts; i++) {
    const x = i * step;
    let y = prevY + (Math.random()-0.5)*15 + trend;
    y = Math.max(5, Math.min(h-5, y));
    if(i===0) ctx.moveTo(x,y);
    else ctx.lineTo(x,y);
    prevY = y;
  }
  ctx.stroke();
  
  // gradient fill
  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0,0,0,h);
  grad.addColorStop(0, ctx.strokeStyle + '66'); // 40% opacity
  grad.addColorStop(1, 'transparent');
  ctx.fillStyle = grad;
  ctx.fill();
}

/* =========================================================
   TAB 2: DIGITAL TWIN SIMULATOR
========================================================= */
let simState = {
  mode: 'flood', // flood or fire
  waterLevel: 1.2,
  riseRate: 1.5,
  rainfall: 5.0,
  prob: 8.4,
  conf: 95.2,
  temp: 24.5,
  hum: 65,
  smoke: 0.01,
  snr: 8.5
};

function renderSimCards() {
  const container = document.getElementById('sim-readouts');
  const svg = document.getElementById('sim-link-graph');
  
  if(simState.mode === 'flood') {
    svg.style.display = 'none';
    container.innerHTML = `
      <div class="readout-card">
        <div class="detail-lbl">Water Level (m)</div>
        <div class="readout-val" id="sim-water">1.20</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">Rise Rate (cm/10m)</div>
        <div class="readout-val" id="sim-rise">1.5</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">Rainfall (mm/hr)</div>
        <div class="readout-val" id="sim-rain">5.0</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">AI Probability</div>
        <div class="readout-val" id="sim-prob">8.4%</div>
      </div>
      <div class="readout-card" style="grid-column: span 2;">
        <div class="detail-lbl">Sensor Health & Risk</div>
        <div style="margin-top:15px; display:flex; gap:10px; justify-content:center;">
          <span class="badge normal" id="sim-health" style="font-size:1rem; padding:8px 16px;">Sensor Normal</span>
          <span class="badge normal" id="sim-risk" style="font-size:1rem; padding:8px 16px;">Risk: NORMAL</span>
        </div>
      </div>
    `;
    // ensure values are reset
    updateSimColors('normal');
  } else {
    svg.style.display = 'block';
    container.innerHTML = `
      <div class="readout-card">
        <div class="detail-lbl">Temperature (°C)</div>
        <div class="readout-val" id="sim-temp">24.5</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">Humidity (%)</div>
        <div class="readout-val" id="sim-hum">65</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">Smoke (mg/m³)</div>
        <div class="readout-val" id="sim-smoke">0.01</div>
      </div>
      <div class="readout-card">
        <div class="detail-lbl">Avg SNR (dB)</div>
        <div class="readout-val" id="sim-snr">8.5</div>
      </div>
    `;
    drawSimLinkGraph('normal');
  }
}

function updateSimColors(level) {
  const riskBadge = document.getElementById('sim-risk');
  const probVal = document.getElementById('sim-prob');
  if(!riskBadge) return;
  
  riskBadge.className = 'badge';
  let colorVar = '';
  if(level === 'normal') { riskBadge.classList.add('normal'); riskBadge.innerText = 'Risk: NORMAL'; colorVar = 'var(--color-green)'; }
  if(level === 'watch') { riskBadge.classList.add('suspicious'); riskBadge.innerText = 'Risk: WATCH'; colorVar = 'var(--color-yellow)'; }
  if(level === 'warning') { riskBadge.classList.add('suspicious'); riskBadge.innerText = 'Risk: WARNING'; colorVar = 'var(--color-orange)'; }
  if(level === 'critical') { riskBadge.classList.add('failed'); riskBadge.innerText = 'Risk: CRITICAL'; colorVar = 'var(--color-red)'; }
  
  if(probVal) probVal.style.color = colorVar;
}

function drawSimLinkGraph(state) {
  const svg = document.getElementById('sim-link-graph');
  const w = svg.clientWidth || 800;
  const h = svg.clientHeight || 120;
  
  const nodes = [
    {x: w*0.1, y: h/2, id:'R-1'}, {x: w*0.3, y: h*0.3, id:'R-2'}, 
    {x: w*0.5, y: h*0.7, id:'R-3'}, {x: w*0.7, y: h/2, id:'R-4'}, 
    {x: w*0.9, y: h*0.4, id:'R-5'}
  ];
  const links = [[0,1], [1,2], [2,3], [3,4], [1,3]];
  
  let html = '';
  links.forEach((l, i) => {
    let cls = 'mesh-link';
    if(state === 'anomaly') {
      if(i === 2 || i === 4) cls += ' broken';
      else if(i === 3) cls += ' degraded';
    }
    html += `<line x1="${nodes[l[0]].x}" y1="${nodes[l[0]].y}" x2="${nodes[l[1]].x}" y2="${nodes[l[1]].y}" class="${cls}" />`;
  });
  
  nodes.forEach(n => {
    html += `<circle cx="${n.x}" cy="${n.y}" r="6" class="mesh-node ${state==='anomaly'?'fire':''}" />`;
    html += `<text x="${n.x}" y="${n.y-12}" class="mesh-label" text-anchor="middle">${n.id}</text>`;
  });
  
  if(state === 'anomaly') {
    html += `<text x="${w/2}" y="${h-10}" fill="var(--color-orange)" font-family="monospace" font-size="12" text-anchor="middle" font-weight="bold">SPREAD DIRECTION: NE</text>`;
  }
  
  svg.innerHTML = html;
}

let simTimeout = null;

function runSim(scenario) {
  clearTimeout(simTimeout);
  const banner = document.getElementById('sim-banner');
  const reason = document.getElementById('sim-reasoning');
  banner.style.display = 'none';
  
  if(scenario === 'rain') {
    if(simState.mode !== 'flood') { simState.mode = 'flood'; renderSimCards(); }
    
    // Animate values
    tweenNumber(document.getElementById('sim-water'), 1.2, 3.72, 6000, v=>v.toFixed(2), 'water');
    tweenNumber(document.getElementById('sim-rise'), 1.5, 12.0, 5000, v=>v.toFixed(1), 'rise');
    tweenNumber(document.getElementById('sim-rain'), 5.0, 58.0, 4000, v=>v.toFixed(1), 'rain');
    
    // Custom probability tween to handle color shifts
    const probEl = document.getElementById('sim-prob');
    const startP = 8.4, endP = 91.0, dur = 6000, startT = performance.now();
    const upProb = (t) => {
      const p = Math.min((t - startT)/dur, 1);
      const val = startP + (endP - startP)*p;
      probEl.innerText = val.toFixed(1) + '%';
      
      if(val > 80) updateSimColors('critical');
      else if(val > 50) updateSimColors('warning');
      else if(val > 30) updateSimColors('watch');
      else updateSimColors('normal');
      
      if(val > 85 && banner.style.display === 'none') {
        banner.style.display = 'block';
      }
      
      if(p < 1) activeTweens['prob'] = requestAnimationFrame(upProb);
    };
    requestAnimationFrame(upProb);
    
    reason.innerText = "Simulating... Upstream rain accumulating.";
    simTimeout = setTimeout(() => {
      reason.innerHTML = "Water level 3.72m + rise rate 12cm/10min + rainfall 58mm/hr &rarr; fused probability 91%. <span style='color:var(--color-red)'>CRITICAL RISK THRESHOLD CROSSED.</span>";
    }, 6000);
    
  } else if(scenario === 'failure') {
    if(simState.mode !== 'flood') { simState.mode = 'flood'; renderSimCards(); }
    
    // Jump abruptly
    setTimeout(() => {
      document.getElementById('sim-water').innerText = '0.20'; // implausible drop
      document.getElementById('sim-rise').innerText = '-350.0'; 
      
      const health = document.getElementById('sim-health');
      health.className = 'badge suspicious';
      health.innerText = 'Suspicious Data';
      
      reason.innerText = "Anomaly detected: Instantaneous drop in water level exceeds physical limits.";
      
      simTimeout = setTimeout(() => {
        health.className = 'badge failed';
        health.innerText = 'Sensor Failed';
        updateSimColors('normal'); // reset risk since sensor is ignored
        document.getElementById('sim-prob').innerText = 'N/A';
        document.getElementById('sim-prob').style.color = 'var(--text-muted)';
        
        reason.innerHTML = "<span style='color:var(--color-red)'>Reading inconsistent with rate-of-change history &mdash; flagged, not trusted, maintenance ticket auto-generated.</span>";
      }, 2000);
    }, 500);
    
  } else if(scenario === 'fire') {
    if(simState.mode !== 'fire') { simState.mode = 'fire'; renderSimCards(); }
    
    tweenNumber(document.getElementById('sim-temp'), 24.5, 62.3, 7000, v=>v.toFixed(1), 'temp');
    tweenNumber(document.getElementById('sim-hum'), 65, 18, 7000, v=>Math.round(v), 'hum');
    tweenNumber(document.getElementById('sim-smoke'), 0.01, 12.5, 6000, v=>v.toFixed(2), 'smoke');
    tweenNumber(document.getElementById('sim-snr'), 8.5, -12.0, 5000, v=>v.toFixed(1), 'snr');
    
    reason.innerText = "RF Link Quality degrading on Nodes R-3 and R-4. Correlating with temp spike...";
    
    setTimeout(() => drawSimLinkGraph('anomaly'), 3000);
    
    simTimeout = setTimeout(() => {
      reason.innerHTML = "<span style='color:var(--color-orange)'>Thermal spike + rapid humidity drop + multi-node RSSI degradation &rarr; Fire Signature Confirmed. Spread vector calculated.</span>";
    }, 6000);
    
  } else if(scenario === 'reset') {
    simState.mode = 'flood';
    renderSimCards();
    reason.innerText = "System nominal. Baseline readings within expected seasonal parameters. No immediate hazards detected.";
  }
}

/* =========================================================
   TAB 3: RF MESH NETWORK
========================================================= */
let meshInitialized = false;
const mNodes = [];
const mLinks = [];

function initMesh() {
  const svg = document.getElementById('mesh-svg');
  const w = svg.clientWidth;
  const h = svg.clientHeight;
  
  // Create 10 nodes
  for(let i=0; i<10; i++) {
    mNodes.push({
      id: 'N-' + pad(i+1),
      x: w * (0.1 + Math.random()*0.8),
      y: h * (0.1 + Math.random()*0.8),
      status: 'normal'
    });
  }
  
  // Create links (Delaunay-ish, just distance based)
  for(let i=0; i<mNodes.length; i++) {
    for(let j=i+1; j<mNodes.length; j++) {
      const dx = mNodes[i].x - mNodes[j].x;
      const dy = mNodes[i].y - mNodes[j].y;
      const dist = Math.sqrt(dx*dx + dy*dy);
      if(dist < w*0.35) { // connect if close
        mLinks.push({ s: i, t: j, status: 'normal', rssi: -40 - Math.floor(Math.random()*30) });
      }
    }
  }
  
  renderMesh();
  startHeartbeat();
  meshInitialized = true;
}

function renderMesh() {
  const svg = document.getElementById('mesh-svg');
  let html = '';
  
  mLinks.forEach(l => {
    const n1 = mNodes[l.s], n2 = mNodes[l.t];
    let cls = 'mesh-link';
    if(l.status === 'degraded') cls += ' degraded';
    if(l.status === 'broken') cls += ' broken';
    
    html += `<line x1="${n1.x}" y1="${n1.y}" x2="${n2.x}" y2="${n2.y}" class="${cls}" id="link-${l.s}-${l.t}" />`;
    
    // Label at midpoint
    const mx = (n1.x + n2.x)/2;
    const my = (n1.y + n2.y)/2;
    html += `<text x="${mx}" y="${my-5}" class="link-label" text-anchor="middle" id="lbl-${l.s}-${l.t}">${l.rssi}dBm</text>`;
  });
  
  mNodes.forEach((n, i) => {
    let cls = 'mesh-node';
    if(n.status === 'fire') cls += ' fire';
    if(n.status === 'offline') cls += ' offline';
    html += `<circle cx="${n.x}" cy="${n.y}" r="8" class="${cls}" id="node-${i}" />`;
    html += `<text x="${n.x}" y="${n.y-15}" class="mesh-label" text-anchor="middle">${n.id}</text>`;
  });
  
  svg.innerHTML = html;
}

let hbInterval;
function startHeartbeat() {
  const consoleEl = document.getElementById('mesh-console');
  let counter = 0;
  
  hbInterval = setInterval(() => {
    if(counter % 2 === 0) {
      const nIdx = Math.floor(Math.random() * mNodes.length);
      const n = mNodes[nIdx];
      if(n.status === 'normal') {
        logMesh(`${getTime()} &mdash; Node ${n.id} heartbeat OK &mdash; RSSI -${50+Math.floor(Math.random()*30)}dBm`);
      }
    }
    counter++;
  }, 1000);
}

function logMesh(msg, type='normal') {
  const consoleEl = document.getElementById('mesh-console');
  const div = document.createElement('div');
  div.className = `log-entry ${type}`;
  div.innerHTML = msg;
  consoleEl.appendChild(div);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}

function triggerMeshFire() {
  // Target N-08 (index 7)
  const tIdx = 7; 
  if(!mNodes[tIdx]) return;
  
  mNodes[tIdx].status = 'fire';
  
  // Find connected links and degrade them
  mLinks.forEach(l => {
    if(l.s === tIdx || l.t === tIdx) {
      l.status = 'degraded';
      l.rssi = -95;
    }
  });
  renderMesh();
  
  logMesh(`${getTime()} &mdash; Node ${mNodes[tIdx].id} heartbeat MISSED &mdash; 1st warning`, 'missed');
  
  setTimeout(() => {
    logMesh(`${getTime()} &mdash; Node ${mNodes[tIdx].id} heartbeat MISSED &mdash; 2nd consecutive`, 'missed');
  }, 1500);
  
  setTimeout(() => {
    mNodes[tIdx].status = 'offline';
    mLinks.forEach(l => {
      if(l.s === tIdx || l.t === tIdx) l.status = 'broken';
    });
    renderMesh();
    logMesh(`${getTime()} &mdash; Node ${mNodes[tIdx].id} &rarr; OFFLINE &mdash; last-gasp packet received: temp=61°C`, 'offline');
    
    // Spread to neighbors
    const neighbors = [8, 9]; // Arbitrary simulation targets
    neighbors.forEach((nIdx, i) => {
      setTimeout(() => {
        if(mNodes[nIdx]) {
          mNodes[nIdx].status = 'fire';
          mLinks.forEach(l => {
             if(l.s === nIdx || l.t === nIdx) { l.status = 'degraded'; l.rssi = -90; }
          });
          renderMesh();
          logMesh(`${getTime()} &mdash; Node ${mNodes[nIdx].id} reporting rapid thermal increase.`, 'missed');
        }
      }, 2000 * (i+1));
    });
    
    setTimeout(() => {
      const summary = document.getElementById('mesh-summary');
      document.getElementById('mesh-summary-text').innerText = "Zone B-12: fire confidence 87%, 3 nodes affected, spread direction NE";
      summary.style.display = 'block';
    }, 6000);
    
  }, 3500);
}

/* =========================================================
   INITIALIZATION
========================================================= */
window.onload = () => {
  initMap();
  renderSimCards(); // init tab 2 default
};

</script>
</body>
</html>
"""

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)
