def main():
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EIN — Environmental Intelligence Network</title>
<style>
/* CSS will be inserted here */
</style>
</head>
<body>
<!-- HTML will be inserted here -->
<script>
/* JS will be inserted here */
</script>
</body>
</html>
"""
    with open('index.html', 'w') as f:
        f.write(html_content)

if __name__ == '__main__':
    main()
