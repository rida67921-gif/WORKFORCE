import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

assert '<style>' in content, "Missing inline <style>"
assert '<script>' in content, "Missing inline <script>"
assert 'http' not in content or 'xmlns="http://www.w3.org/2000/svg"' in content, "Found potential external links"
assert 'src=' not in content, "Found src attributes which might mean external requests"
assert 'link href=' not in content, "Found link elements which might mean external CSS"
assert 'import' not in content or 'important' in content, "Found import statements"

print("Standalone checks passed.")
